package Chuong3;

import java.util.Scanner;

public class Baitap3_2 {
    //Khai bao doi tuong input cua lop Scaner nhan du lieu nhap vao
    private static Scanner input;

    //Chuong trinh chinh
    public static void main(String[] args) {
        //Khoi tao doi tuong input
        input = new Scanner(System.in);
        //Nhap gia tri cho he so a, b, c kieu so thuc tu ban phim
        System.out.printf("Nhập a: ");
        Float a = input.nextFloat();
        System.out.printf("Nhập b: ");
        Float b = input.nextFloat();
        System.out.printf("Nhập c: ");
        Float c = input.nextFloat();
        //Tinh gia tri delta
        Float delta=b*b-4*a*c;
        //Xet cac truong hop cua delta de cho ra nghiem
        if (delta<0)
            System.out.printf("Phương trình vô nghiệm.");
        else if (delta==0)
            System.out.printf("Phương trình có nghiệm kép: "+(-b/(2*a)));
        else{
            System.out.printf("Phương trình có 2 nghiệm:");
            System.out.printf("X1 ="+(-b+Math.sqrt(delta))/(2*a));
            System.out.printf("X2 ="+(-b-Math.sqrt(delta))/(2*a));
        }

    }
}
