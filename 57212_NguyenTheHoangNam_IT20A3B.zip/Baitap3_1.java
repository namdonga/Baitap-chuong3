package Chuong3;

import java.util.Scanner;

public class Baitap3_1 {
    //Khai bao doi tuong input cua lop Scaner nhan du lieu nhap vao
    private static Scanner input;

    //Chuong trinh chinh
    public static void main(String[] args) {
        //Khoi tao doi tuong input
        input = new Scanner(System.in);
        //Nhap gia tri cho bien a, b kieu so thuc tu ban phim
        System.out.printf("nhap a");
        float a = input.nextFloat();
        System.out.printf("nhap b");
        float b = input.nextFloat();
        //Hien thiket qua tinh toan ra man hinh
        System.out.printf("Ket qua bai toan a + b la " + (a+b));
        System.out.printf("Ket qua bai toan a - b la " + (a-b));
        System.out.printf("Ket qua bai toan a * b la " + (a*b));
        System.out.printf("Ket qua bai toan a / b la " + (a/b));
    }
}
